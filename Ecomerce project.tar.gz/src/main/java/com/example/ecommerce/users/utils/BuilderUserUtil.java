package com.example.ecommerce.users.utils;

import com.example.ecommerce.auth.dtos.SignUpDTO;
import com.example.ecommerce.users.models.User;
import jakarta.validation.Valid;

public class BuilderUserUtil {

  public static User build(@Valid SignUpDTO dto) {
    return User.builder()
        .name(dto.name())
        .email(dto.email())
        .isEnabled(true)
        .accountLocked(false)
        .credentialsExpired(false)
        .build();
  }
}

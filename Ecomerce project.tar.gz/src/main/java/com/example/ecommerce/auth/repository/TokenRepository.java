package com.example.ecommerce.auth.repository;

import com.example.ecommerce.auth.model.Token;
import com.example.ecommerce.users.models.User;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TokenRepository extends JpaRepository<Token, UUID> {

  @Query("SELECT t FROM Token t WHERE t.user = :user")
  public List<Token> getAllTokensFromUser(@Param("user") User user);

  @Query("SELECT t FROM Token t WHERE t.revoked=true AND t.expired=true")
  public List<Token> getAllInvalidTokens();

  @Query("SELECT t FROM Token t WHERE t.value= :value")
  public Optional<Token> findByValue(@Param("value") String value);
}

package com.example.ecommerce.auth.config;

import com.example.ecommerce.auth.filters.ExceptionHandlerFilter;
import com.example.ecommerce.auth.filters.JwtAuthFilter;
import com.example.ecommerce.logging.filters.LoggingMiddleware;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@RequiredArgsConstructor
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
  private final JwtAuthFilter jwtAuthFilter;
  private final AuthenticationProvider authenticationProvider;
  private final ExceptionHandlerFilter exceptionHandlerFilter;
  private final LoggingMiddleware loggingMiddleware;

  @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

    http.csrf(AbstractHttpConfigurer::disable)
        .authorizeHttpRequests(
            auth ->
                auth.requestMatchers("/api/v1/auth/**")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/products/**")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/products/")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/products/search")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/categories/")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/categories/**")
                    .permitAll()
                    .requestMatchers(
                        "/api/v1/auth/**",
                        "/swagger-ui/**",
                        "/swagger-ui.html",
                        "/v3/api-docs/**",
                        "/actuator",
                        "/actuator/**")
                    .permitAll()
                    .requestMatchers("/api/v1/users/**")
                    .authenticated()
                    .requestMatchers(HttpMethod.PUT, "/api/v1/users/*")
                    .authenticated()
                    .requestMatchers(HttpMethod.PUT, "/api/v1/cart/*")
                    .authenticated()
                    .requestMatchers("/api/v1/me/**")
                    .authenticated()
                    .anyRequest()
                    .authenticated())
        .sessionManagement(
            session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .authenticationProvider(authenticationProvider)
        .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
        .addFilterBefore(exceptionHandlerFilter, JwtAuthFilter.class);

    return http.build();
  }
}

package com.example.ecommerce.integrationTests.payment;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.example.ecommerce.integrationTests.globalconftest.GlobalConftest;
import com.example.ecommerce.order.dtos.order.OrderAllDetailsDTO;
import com.example.ecommerce.order.service.OrderService;
import com.example.ecommerce.payments.dto.CreatePaymentDto;
import com.example.ecommerce.payments.model.Payment;
import com.example.ecommerce.payments.paymentintentwrapper.PaymentIntentWraper;
import com.example.ecommerce.payments.service.PaymentService;
import com.example.ecommerce.payments.status.PaymentStatus;
import com.example.ecommerce.users.models.User;
import com.stripe.exception.StripeException;
import com.stripe.model.Event;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;

@SpringBootTest(webEnvironment = WebEnvironment.NONE)
@DirtiesContext(classMode = ClassMode.BEFORE_EACH_TEST_METHOD)
@Sql(
    scripts = {"/clean.sql", "/data.sql"},
    executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
public class TestPaymentSevice {
  @Autowired private PaymentService service;
  @Autowired private OrderService orderService;
  @Autowired private GlobalConftest globalConftest;
  @MockitoBean private PaymentIntentWraper wrapper;

  CreatePaymentDto paymentDto;

  @BeforeEach
  public void createOrderAndReturnCreatePaymentDto() {
    User user = globalConftest.createUser();
    OrderAllDetailsDTO order = orderService.createOrder(UUID.randomUUID(), user.getEmail());

    paymentDto = CreatePaymentDto.builder().currency("usd").orderId(order.id()).build();
  }

  @BeforeEach
  public void mockPaymentIntent() throws StripeException {

    PaymentIntent fakePaymentIntent = new PaymentIntent();
    fakePaymentIntent.setId("id_43");
    fakePaymentIntent.setCurrency("usd");

    when(wrapper.createPaymentIntent(any(PaymentIntentCreateParams.class)))
        .thenReturn(fakePaymentIntent);
  }

  @Test
  @DisplayName("Should save payment entity")
  public void shouldSavePaymentEntity() throws StripeException {

    PaymentIntent intent = service.createIntentAndSavePayment(paymentDto);
    Payment payment = service.findByOrderIdOrThrow(1L);

    assertThat(payment.getPaymentIntentId()).isEqualTo(intent.getId());
    assertThat(payment.getCurrency()).isEqualTo("usd");
    assertThat(payment.getStatus()).isEqualTo(PaymentStatus.PENDING);
  }

  @Test
  @DisplayName("Should set PAID PaymentStatus")
  public void shouldSetPaidPaymentStatus() throws StripeException {
    PaymentIntent intent = service.createIntentAndSavePayment(paymentDto);
    Payment payment = service.findByOrderIdOrThrow(1L);
    Event event = new Event();
    event.setId("453");
    event.setType("payment_intent.succeeded");

    service.updatePaymentStatus(intent.getId(), event);
    Payment updatePayment = service.findByOrderIdOrThrow(1L);

    assertThat(payment.getStatus()).isEqualTo(PaymentStatus.PENDING);
    assertThat(updatePayment.getStatus()).isEqualTo(PaymentStatus.PAID);
  }

  @Test
  @DisplayName("Should set FAILED PaymentStatus")
  public void shouldSetFailedPaymentStatus() throws StripeException {
    PaymentIntent intent = service.createIntentAndSavePayment(paymentDto);
    Payment payment = service.findByOrderIdOrThrow(1L);
    Event event = new Event();
    event.setId("453");
    event.setType("payment_intent.payment_failed");

    service.updatePaymentStatus(intent.getId(), event);
    Payment updatePayment = service.findByOrderIdOrThrow(1L);

    assertThat(payment.getStatus()).isEqualTo(PaymentStatus.PENDING);
    assertThat(updatePayment.getStatus()).isEqualTo(PaymentStatus.FAILED);
  }
}

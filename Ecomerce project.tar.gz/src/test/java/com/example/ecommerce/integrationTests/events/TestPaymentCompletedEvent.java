package com.example.ecommerce.integrationTests.events;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.example.ecommerce.cart.services.CartService;
import com.example.ecommerce.integrationTests.globalconftest.GlobalConftest;
import com.example.ecommerce.order.dtos.order.OrderAllDetailsDTO;
import com.example.ecommerce.order.models.Order;
import com.example.ecommerce.order.models.OrderStatus;
import com.example.ecommerce.order.service.OrderService;
import com.example.ecommerce.payments.dto.CreatePaymentDto;
import com.example.ecommerce.payments.model.Payment;
import com.example.ecommerce.payments.paymentintentwrapper.PaymentIntentWraper;
import com.example.ecommerce.payments.service.PaymentService;
import com.example.ecommerce.payments.status.PaymentStatus;
import com.example.ecommerce.products.model.Product;
import com.example.ecommerce.users.models.User;
import com.stripe.exception.StripeException;
import com.stripe.model.Event;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;

@SpringBootTest(webEnvironment = WebEnvironment.NONE)
@Transactional
@Sql(
    scripts = {"/clean.sql", "/data.sql"},
    executionPhase = ExecutionPhase.BEFORE_TEST_CLASS)
public class TestPaymentCompletedEvent {
  @Autowired private OrderService orderService;
  @Autowired private PaymentService paymentService;
  @Autowired private GlobalConftest conftest;
  @Autowired private CartService cartService;
  @MockitoBean private PaymentIntentWraper wraper;

  public CreatePaymentDto createOrderAndReturnCreatePaymentDto() {
    User user = conftest.createUser();
    cartService.addItem(user.getId(), 16, 2);
    cartService.addItem(user.getId(), 17, 4);
    cartService.addItem(user.getId(), 19, 5);

    OrderAllDetailsDTO order = orderService.createOrder(UUID.randomUUID(), user.getEmail());

    return CreatePaymentDto.builder().currency("usd").orderId(order.id()).build();
  }

  @BeforeEach
  public void mockPaymentIntentWraper() throws StripeException {

    PaymentIntent fakePaymentIntent = new PaymentIntent();
    fakePaymentIntent.setId("id_43");
    fakePaymentIntent.setCurrency("usd");

    when(wraper.createPaymentIntent(any(PaymentIntentCreateParams.class)))
        .thenReturn(fakePaymentIntent);
  }

  private void savePaymentEntity() throws StripeException {
    CreatePaymentDto dto = createOrderAndReturnCreatePaymentDto();
    paymentService.createIntentAndSavePayment(dto);
  }

  private Event createFakeEvent() {
    Event event = new Event();
    event.setId("453");
    event.setType("payment_intent.succeeded");
    return event;
  }

  @Test
  public void shouldSetOrderAsPaidAndUpdateProductsStock() throws StripeException {
    savePaymentEntity();
    paymentService.updatePaymentStatus("id_43", createFakeEvent());
    Payment payment = paymentService.findByOrderIdOrThrow(1L);
    Order order = orderService.findEntityByIdOrThrow(1L);
    List<Product> products = order.getOrderDetails().stream().map(itm -> itm.getProduct()).toList();

    Product productWithId16AndInitialStock18 =
        products.stream().filter(pro -> pro.getId().equals(16L)).findFirst().get();
    Product productWithId17AndInitialStock40 =
        products.stream().filter(pro -> pro.getId().equals(17L)).findFirst().get();
    Product productWithId19AndInitialStock18 =
        products.stream().filter(pro -> pro.getId().equals(19L)).findFirst().get();

    assertTrue(payment.getStatus().equals(PaymentStatus.PAID));
    assertTrue(order.getStatus().equals(OrderStatus.PAID));
    assertThat(productWithId16AndInitialStock18.getStock()).isEqualTo(16); // Expected 16
    assertThat(productWithId17AndInitialStock40.getStock()).isEqualTo(36); // Expected 36
    assertThat(productWithId19AndInitialStock18.getStock()).isEqualTo(13); // Expected 13
  }
}

package com.example.ecommerce.testServices;

import static org.junit.jupiter.api.Assertions.*;

import com.example.ecommerce.categories.model.Category;
import com.example.ecommerce.products.DTOs.CreateProductDTO;
import com.example.ecommerce.products.DTOs.ProductDetailsDTO;
import com.example.ecommerce.products.DTOs.ProductListDTO;
import com.example.ecommerce.products.DTOs.SearchProductDTO;
import com.example.ecommerce.products.DTOs.UpdateProductDTO;
import com.example.ecommerce.products.model.Product;
import com.example.ecommerce.products.services.ProductService;
import com.example.ecommerce.products.utils.ProductSortCriteria;
import com.example.ecommerce.shared.exceptions.AlreadyExistsException;
import com.example.ecommerce.shared.exceptions.InvalidRequestException;
import com.example.ecommerce.shared.utils.PaginationCriteria;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("test")
@Sql(
    scripts = {"/clean.sql"},
    executionPhase = ExecutionPhase.BEFORE_TEST_CLASS)
public class TestProductService {
  @Autowired private ProductService service;
  @Autowired private ProductTestServiceHelper conftest;

  public CreateProductDTO buildCreateProductDtoHelper(
      String name, String description, String pic, Double price, Integer stock, Long categoryId) {
    return CreateProductDTO.builder()
        .name(name)
        .description(description)
        .pic(pic)
        .price(price)
        .stock(stock)
        .categoryId(categoryId)
        .build();
  }

  @ParameterizedTest
  @CsvSource({
    "Cama, Una cama suave, dhfghfhg, 200.00, 50",
    "Armario,, ddsfsd, 50.0, 45",
    "Silla,,,400.0,"
  })
  void shouldCreateProductUsingCreateProductDTOInEveryCase(
      String name, String description, String pic, Double price, Integer stock) {

    Category category = conftest.createCategory();
    CreateProductDTO dto =
        buildCreateProductDtoHelper(name, description, pic, price, stock, category.getId());
    ProductDetailsDTO product = service.createProduct(dto);

    assertNotNull(product.id());
    assertEquals(product.name(), name);
    assertTrue(product.isAvailable());
  }

  @ParameterizedTest
  @CsvSource({
    "null, Un bonito armario, fsfsgs, 20.0, 40",
    "Helado, Un rico helado,, 60.0, 100",
    "Botas de agua, Muy buenas botas, eqweq, 70.0, 57"
  })
  void shouldFailWhenCreatingEachProduct(
      String name, String description, String pic, Double price, Integer stock) {

    conftest.createProductWithNameEqualHelado();
    Category category = conftest.createCategory();
    CreateProductDTO product =
        buildCreateProductDtoHelper(name, description, pic, price, stock, category.getId());

    if (name == null) {
      assertThrows(
          InvalidRequestException.class,
          () -> {
            service.createProduct(product);
          });

    } else if (name.equals("Helado")) {
      assertThrows(
          AlreadyExistsException.class,
          () -> {
            service.createProduct(product);
          });
    }
  }

  @ParameterizedTest
  @CsvSource({
    "Chocolate, Un rico chocolate, dhfghfhg, 200.00, 50",
    "TV LG,, ddsfsd, 50.0, 45",
    "Coche Audi,,,400.0,"
  })
  @DirtiesContext
  void shouldUpdateProductWithData(
      String name, String description, String pic, Double price, Integer stock) {
    Product product = conftest.createProductWithNameEqualHelado();

    UpdateProductDTO updateData =
        UpdateProductDTO.builder()
            .name(name)
            .description(description)
            .pic(pic)
            .price(price)
            .build();

    ProductDetailsDTO updatedProduct = service.updateProduct(updateData, product.getId());

    assertEquals(updatedProduct.name(), name);
    assertEquals(product.getId(), updatedProduct.id());

    if (description != null) {
      assertEquals(description, updatedProduct.description());

    } else {
      assertEquals(product.getDescription(), updatedProduct.description());
    }

    if (price != null) {
      assertEquals(updatedProduct.price(), price);

    } else {
      assertEquals(updatedProduct.price(), product.getPrice());
    }
  }

  @Test
  @Sql("/data.sql")
  void shouldSearchProductsUsingConditions() {
    var pc = new PaginationCriteria<ProductSortCriteria>(0, 10, ProductSortCriteria.ID, true);
    SearchProductDTO data =
        SearchProductDTO.builder().maxPrice(130.0).minPrice(40.0).paginationCriteria(pc).build();
    SearchProductDTO data2 =
        SearchProductDTO.builder().name("Laptop").paginationCriteria(pc).build();

    Page<ProductListDTO> products = service.searchProducts(data);
    Page<ProductListDTO> laptops = service.searchProducts(data2);
    assertEquals(3, laptops.getNumberOfElements());
    assertTrue(products.getNumberOfElements() > 0);
  }
}
